import numpy as np
from scipy import integrate

t = []
drag = []
lift = []

with open(f"bench_values_3d_feat.txt", "r") as f:
    for i, line in enumerate(f):
        if i > 0:
            vals = line.strip("\n").split()
            if len(vals) == 0:
                continue
            t.append(np.float64(vals[0]))
            drag.append(np.float64(vals[1]))
            lift.append(np.float64(vals[2]))

t_start = t[0]
k = t[1] - t[0]
t_end = t[-1]
#print(t_end)

I1 = integrate.trapz(drag, t)
# print(I1/t_end)
# print(I1/8.)
print("drag =", (0.5*(np.array(drag)[:-2]+np.array(drag)[1:-1])*k).sum()/8.)

I2 = integrate.trapz(lift, t)
# print(I2/t_end)
# print(I2/8.)
print("lift =", (0.5*(np.array(lift)[:-2]+np.array(lift)[1:-1])*k).sum()/8.)
