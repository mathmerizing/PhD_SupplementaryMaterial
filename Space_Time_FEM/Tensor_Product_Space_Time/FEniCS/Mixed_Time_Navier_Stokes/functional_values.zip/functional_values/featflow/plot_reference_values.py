import numpy as np

t = []
drag = []
lift = []

with open(f"bdforces_lv6", "r") as f:
    for i, line in enumerate(f):
        if i > 0:
            vals = line.strip("\n").split()
            t.append(np.float64(vals[1]))
            drag.append(np.float64(vals[3]))
            lift.append(np.float64(vals[4]))

t2 = []
pressure = []
with open(f"pointvalues_lv6", "r") as f:
    for i, line in enumerate(f):
        if i > 0:
            vals = line.strip("\n").split()
            t2.append(np.float64(vals[1]))
            pressure.append(np.float64(vals[6])-np.float64(vals[11]))
            
goal_functionals = {"drag": drag, "lift": lift, "pressure": pressure}
for name, values in goal_functionals.items():
  with open(f"{name}_featflow.dat", "w") as f:
    f.write("x,y\n")
    for _t, _val in zip(t, values):
      f.write(f"{_t},{_val}\n")
    