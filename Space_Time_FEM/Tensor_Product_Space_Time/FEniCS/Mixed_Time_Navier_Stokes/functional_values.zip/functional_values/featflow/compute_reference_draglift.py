import numpy as np
from scipy import integrate

for i in range(1,7):
    print("lvl =", i)
    t = []
    drag = []
    lift = []

    with open(f"bdforces_lv{i}", "r") as f:
        for i, line in enumerate(f):
            if i > 0:
                vals = line.strip("\n").split()
                t.append(np.float64(vals[1]))
                drag.append(np.float64(vals[3]))
                lift.append(np.float64(vals[4]))

    t_start = t[0]
    t_end = t[-1]

    I1 = integrate.trapz(drag, t)
    # print(I1/t_end)
    # print(I1/8.)
    print("drag =", (np.array(drag)/1600).sum()/8.)
    
    I2 = integrate.trapz(lift, t)
    # print(I2/t_end)
    # print(I2/8.)
    print("lift =", (np.array(lift)/1600).sum()/8.)
